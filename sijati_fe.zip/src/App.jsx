import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './components/LandingPage'; // pastikan file ini ada
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import Chatbot from './pages/Chatbot';
import UploadDokumen from './pages/UploadDokumen';
import FAQManagement from './pages/FAQManagement';
import StatistikChatbot from './pages/StatistikChatbot';
import DokumenDetail from './pages/DokumenDetail';
import NotFound from './pages/NotFound';
import ResetPasswordPage from './pages/ResetPasswordPage';
import ManagementUser from './pages/ManagementUser';
import LoginLogs from './pages/LoginLogs';
import ChatHistory from './pages/ChatHistory';

function App() {
  return (
    <Router>

      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/chatbot" element={<Chatbot />} />
        <Route path="/chatbot/:session_id" element={<Chatbot />} />
         <Route path="/reset-password" element={<ResetPasswordPage />} />

        {/* Halaman Dashboard/Admin */}
        <Route path="/upload" element={<UploadDokumen />} />
        <Route path="/faq" element={<FAQManagement />} />
        <Route path="/statistik" element={<StatistikChatbot />} />
        <Route path="/dokumen/:id" element={<DokumenDetail />} />
        <Route path="/user-management" element={<ManagementUser />} /> 
        <Route path="/login-logs" element={<LoginLogs />} />
        <Route path="/history" element={<ChatHistory />} />

        {/* Fallback untuk semua route yang tidak ditemukan */}
        <Route path="*" element={<NotFound />} />

        {/* Optional: redirect halaman tidak ditemukan ke landing */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

export default App;
